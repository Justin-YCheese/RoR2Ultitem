## 10.0.0

- Added Pig's Spork
- Rotten Bones Description is now accurate
- Inflated Frisbee
- Renamed Chrysotope -> Crysotope
- Renamed Universal Solute -> Obsolute
- HMT base damage 400% -> 300%
    - damage per stack 125% -> 100%
- Yield Sign damage 350% -> 300%
    - Nolonger can either version can be triggered by Bottled Chaos (Didn't do anything in the first place)
- Removed a few frequent log print messages

## 0.9.3

- Toy Robot Barrier 5 -> 6
- Zorse Pill
    - Starve Effect nolonger spawns when dealing any DoTs
    - Deals proper TOTAL damage
- Sonorous Pail
    - Now gives jump height per Lunar
    - Sonorous Pail no longer disables Bands nor VoidBear (this was actually happens with vanilla restacking, so I made my own method)
    - New restack doesn't regives items, therefore no longer synergizes with silver thread (used to be an immortality build with Sue's Mandables)

## 0.9.2

- Added item table to readme

## 0.9.1

- Fixing the asset bundle?

## 0.9.0

- Early Release