# Ultitems Cyan

Bringing my experiance from making vanilla modded items, this pack contains various items which try to expand on the base game's items.

There are still alot of print messages in the logs because I'm still debugging stuff...

Testing Thunder README...